from typing import List, Type

from project.computer_types.computer import Computer
from project.computer_types.desktop_computer import DesktopComputer
from project.computer_types.laptop import Laptop


class ComputerStoreApp:
    VALID_PCs = {"Desktop Computer": DesktopComputer, "Laptop": Laptop}

    def __init__(self):
        self.warehouse: List[Type[Computer]] = []
        self.profits: int = 0

    def build_computer(self, type_computer: str, manufacturer: str, model: str, processor: str, ram: int):
        if type_computer not in self.VALID_PCs:
            raise ValueError(f"{type_computer} is not a valid type computer!")
        pc = self.VALID_PCs[type_computer](manufacturer, model)
        builder = pc.configure_computer(processor, ram)
        self.warehouse.append(pc)
        return builder

    def sell_computer(self, client_budget: int, wanted_processor: str, wanted_ram: int):
        for x in self.warehouse:
            if x.price <= client_budget:
                if x.processor == wanted_processor:
                    if x.ram >= wanted_ram:
                        self.profits += client_budget - x.price
                        self.warehouse.remove(x)
                        return f"{repr(x)} sold for {client_budget}$."
                    continue
                continue
            continue
        else:
            raise Exception("Sorry, we don't have a computer for you.")
