from project.motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    def drive(self, kilometers):
        super().drive(kilometers)
