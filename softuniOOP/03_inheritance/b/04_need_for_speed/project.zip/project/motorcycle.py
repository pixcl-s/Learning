from project.vehicle import Vehicle


class Motorcycle(Vehicle):
    def drive(self, kilometers):
        super().drive(kilometers)
